<?php
    require 'cabecalho';

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Destino do Formulário (inserção)</h1>
    </div>
    <br>

    <?php
     $nome = filter_input(INPUT_POST , "nome", FILTER_SANITIZE_SPECIAL_CHARS);
     $preco = filter_input(INPUT_POST , "preco" ,FILTER_SANITIZE_NUMBER_FLOAT);
     $url = filter_input(INPUT_POST, "url", FILTER_SANITIZE_URL);
     $descricao = filter_input(INPUT_POST, "descricao", FILTER_SANITIZE_SPECIAL_CHARS);

        echo "<strong>Nome:</strong> $nome";
        echo "<strong>Preço:</strong> $preco";
        echo "<strong>URL Foto:</strong> $url";
        echo "<strong>Descrição do produto:</strong> $descricao";
        
    ?>

<?php
    require 'rodape';
?>